
drop table users;